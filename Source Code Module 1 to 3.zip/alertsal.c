//
//  alertsal.c
//  
//
//  Created by Estevan Hernandez on 5/6/14.
//
//

#include <stdio.h>
int main(void)
{
    printf("\007");
    printf("Startled by the sudden sound, Sally shouted, \"By the Great Pumpkin, what was that?!\"");
}

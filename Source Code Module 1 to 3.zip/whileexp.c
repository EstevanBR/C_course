#include <stdio.h>
int main(void)
{
	int test = 0;

	while(1)
	{
		printf("hi\n");
		//eturn 1;
	}

	return 0;

}
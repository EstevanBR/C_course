#include <stdio.h>
int main(void)
{
    printf("\nhello\n");
    getchar();
    
    return 0;
}
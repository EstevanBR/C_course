#define MESG "COMPUTER BYTES DOG"
#include <stdio.h>
int main(void)
{
	int n = 0;

	while ( n < 5 )
		printf("%s", MESG);
		n++;
	printf("That's all\n");
	return 0;
}

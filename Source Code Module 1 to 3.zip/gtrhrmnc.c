/* gtrhrmnc.c

lists the harmonics for a guitar tuned to EADGBE */

#include <stdio.h>
#include <math.h>
#define FACTOR 1.05946309436
int main(void)
{
	const float highe=164.814,lowe=82.407,a=110.000,d=146.832,g=195.998,b=246.942;
	return 0;
}

/*

1.

quack = 2
quack = 7
quack = 70
quack = 64
quack = 8
quack = 2

2.		*/
#include <stdio.h>
int main(void)
{
	double value;
	for ( value = 36; value > 0; value /=21)
		printf("%3d", value);

	return 0;
}
/*
3.
	a. x > 5
	b. while (scanf("%f", &x) == 0 )
	c. x == 5

4.
	a. while(scanf("%d", &int) == 1)
	b. x != 5
	c. x >= 20

5.
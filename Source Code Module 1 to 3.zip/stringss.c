//
//  stringss.c
//  
//
//  Created by Estevan Hernandez on 5/9/14.
//
//

#include <stdio.h>
#include <strings.h>
int main(void)
{
    int hi = 16;
    char greeting[3] = "hi!";
    
    printf("hi = \n%d\n greeting = %s\n", hi, greeting);
    
    return 0;
}
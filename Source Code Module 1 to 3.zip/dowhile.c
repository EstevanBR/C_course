#include <stdio.h>
int main(void)
{
	int pizza = 0;

	do{
		printf("Pizza %d\n", pizza);
	}while(pizza != 0);

	return 0;
}